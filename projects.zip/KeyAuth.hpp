#pragma once
#include <windows.h>
#include <wininet.h>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

#pragma comment(lib, "wininet.lib")

namespace KeyAuth {

    struct AppData {
        std::string numUsers;
        std::string numOnline;
        std::string numKeys;
        std::string version;
        std::string customerPanel;
    };

    struct UserData {
        std::string username;
        std::string ip;
        std::string hwid;
        std::string createdate;
        std::string lastlogin;
        std::vector<std::string> subscriptions;
        std::string expiry;
    };

    class api {
    public:
        std::string name;
        std::string ownerid;
        std::string secret;
        std::string version;
        std::string url;

        AppData app_data;
        UserData user_data;
        std::string sessionid;
        bool response_success = false;
        std::string response_message;

        api(std::string name, std::string ownerid, std::string secret, std::string version, std::string url)
            : name(name), ownerid(ownerid), secret(secret), version(version), url(url) {}

        void init() {
            sessionid.clear();
            std::string post_data = "type=init&ver=" + version + "&name=" + name + "&ownerid=" + ownerid;
            std::string response = req(post_data);

            if (response == "KeyAuth_Invalid") {
                response_success = false;
                response_message = "Application not found or invalid KeyAuth credentials!";
                return;
            }

            // Extract session id
            size_t session_pos = response.find("\"sessionid\":\"");
            if (session_pos != std::string::npos) {
                session_pos += 13;
                size_t end_pos = response.find("\"", session_pos);
                if (end_pos != std::string::npos) {
                    sessionid = response.substr(session_pos, end_pos - session_pos);
                    response_success = true;
                    response_message = "KeyAuth Initialized Successfully!";
                    return;
                }
            }

            response_success = (response.find("\"success\":true") != std::string::npos);
            response_message = extract_json_field(response, "message");
        }

        bool license(std::string key) {
            if (sessionid.empty()) {
                response_success = false;
                response_message = "Session not initialized. Please call init() first.";
                return false;
            }

            std::string post_data = "type=license&key=" + key + "&sessionid=" + sessionid + "&name=" + name + "&ownerid=" + ownerid;
            std::string response = req(post_data);

            response_success = (response.find("\"success\":true") != std::string::npos);
            response_message = extract_json_field(response, "message");

            if (response_success) {
                user_data.username = extract_json_field(response, "username");
                user_data.expiry = extract_json_field(response, "expiry");
            }
            return response_success;
        }

    private:
        static std::string extract_json_field(const std::string& json, const std::string& field) {
            std::string search = "\"" + field + "\":\"";
            size_t pos = json.find(search);
            if (pos != std::string::npos) {
                pos += search.length();
                size_t end_pos = json.find("\"", pos);
                if (end_pos != std::string::npos) {
                    return json.substr(pos, end_pos - pos);
                }
            }
            return "";
        }

        std::string req(const std::string& post_data) {
            HINTERNET hInternet = InternetOpenA("KeyAuth-AutoPanel/1.0", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
            if (!hInternet) return "";

            HINTERNET hConnect = InternetConnectA(hInternet, "keyauth.win", INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
            if (!hConnect) {
                InternetCloseHandle(hInternet);
                return "";
            }

            const char* acceptTypes[] = { "*/*", NULL };
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", "/api/1.2/", NULL, NULL, acceptTypes, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD, 0);
            if (!hRequest) {
                InternetCloseHandle(hConnect);
                InternetCloseHandle(hInternet);
                return "";
            }

            std::string headers = "Content-Type: application/x-www-form-urlencoded\r\n";
            BOOL sent = HttpSendRequestA(hRequest, headers.c_str(), (DWORD)headers.length(), (LPVOID)post_data.c_str(), (DWORD)post_data.length());

            std::string response;
            if (sent) {
                char buffer[4096];
                DWORD bytesRead = 0;
                while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    response += buffer;
                }
            }

            InternetCloseHandle(hRequest);
            InternetCloseHandle(hConnect);
            InternetCloseHandle(hInternet);
            return response;
        }
    };
}
