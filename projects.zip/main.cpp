#include <windows.h>
#include <iostream>
#include <string>
#include "config.h"
#include "KeyAuth.hpp"

void set_console_title() {
    std::string title = std::string(PANEL_NAME) + " | Developed by " + std::string(DEV_NAME) + " [v" + std::string(PANEL_VERSION) + "]";
    SetConsoleTitleA(title.c_str());
}

void print_banner() {
    system("cls");
    system("color 0B"); // Light Aqua text

    std::cout << "\n";
    std::cout << "  ==============================================================\n";
    std::cout << "     " << PANEL_NAME << " - OFFICIAL BUILD\n";
    std::cout << "     Developer: " << DEV_NAME << "  |  Version: " << PANEL_VERSION << "\n";
    std::cout << "  ==============================================================\n\n";
}

int main() {
    set_console_title();
    print_banner();

    std::cout << "  [*] Contacting KeyAuth authentication servers...\n";
    KeyAuth::api keyauth_app(KEYAUTH_NAME, KEYAUTH_OWNERID, KEYAUTH_SECRET, KEYAUTH_VERSION, KEYAUTH_URL);
    keyauth_app.init();

    if (!keyauth_app.response_success && keyauth_app.sessionid.empty()) {
        std::cout << "  [-] Initialization failed: " << keyauth_app.response_message << "\n";
        std::cout << "  [*] Please verify your KeyAuth credentials.\n\n";
        std::cout << "  Press Enter to exit...";
        std::cin.get();
        return 1;
    }

    std::cout << "  [+] KeyAuth Initialized successfully!\n";
    std::cout << "\n  Enter your license key: ";
    std::string license_key;
    std::getline(std::cin, license_key);

    std::cout << "  [*] Verifying license...\n";
    if (keyauth_app.license(license_key)) {
        std::cout << "\n  [+] Access Granted! Welcome to " << PANEL_NAME << "!\n";
        if (!keyauth_app.user_data.username.empty()) {
            std::cout << "  [+] Logged in as: " << keyauth_app.user_data.username << "\n";
        }
        std::cout << "  [+] Expiry: " << keyauth_app.user_data.expiry << "\n\n";

        std::cout << "  ====================== MAIN MENU ======================\n";
        std::cout << "  [1] Launch Feature Suite\n";
        std::cout << "  [2] Check License Information\n";
        std::cout << "  [3] Exit\n";
        std::cout << "  =======================================================\n";
        std::cout << "  Select option: ";

        int choice = 0;
        std::cin >> choice;
        std::cout << "\n  [*] Feature launched. Panel running smoothly.\n";
    } else {
        std::cout << "  [-] Verification Failed: " << keyauth_app.response_message << "\n";
    }

    std::cout << "\n  Press Enter to exit...";
    std::cin.ignore();
    std::cin.get();
    return 0;
}
