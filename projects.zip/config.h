#pragma once

// ============================================================================
// AUTO CUSTOM PANEL MAKER - CONFIGURATION PLACEHOLDERS
// The automated GitHub Actions builder will replace these placeholders
// with the buyer's custom information prior to compilation.
// ============================================================================

#define PANEL_NAME         "__PLACEHOLDER_PANEL_NAME__"
#define DEV_NAME           "__PLACEHOLDER_DEV_NAME__"
#define PANEL_VERSION      "1.0.0"

// KeyAuth Credentials
#define KEYAUTH_NAME       "__PLACEHOLDER_KEYAUTH_NAME__"
#define KEYAUTH_OWNERID    "__PLACEHOLDER_KEYAUTH_OWNERID__"
#define KEYAUTH_SECRET     "__PLACEHOLDER_KEYAUTH_SECRET__"
#define KEYAUTH_VERSION    "__PLACEHOLDER_KEYAUTH_VERSION__"
#define KEYAUTH_URL        "https://keyauth.win/api/1.2/"
